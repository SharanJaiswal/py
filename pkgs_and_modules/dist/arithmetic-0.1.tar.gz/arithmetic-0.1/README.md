Pthon PyPi has all the package indexes. It has two websites:
1. pypi.org (for regular repositories) [public repo index]
2. test.pypy.org    (for regular repositories) [accout on pypi is necessary for account on test]

Goto cmd term at the setup.py file level and type, " python setup.py sdist "